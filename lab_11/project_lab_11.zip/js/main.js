
// Завдання 2 
console.log("Nedoshytko");

// Завдання 3 
let val1;
let val2;
val1 = 2022;
val2 = "year ";
alert("val1= " + val1 + " val2= " + val2);

val1 = val2 + val1;
console.log(val1);

// Завдання 4
const user = { 
    nameUser: "Anhelina", 
    ageUser: 20, 
    isStudent: true, 
    cityUser : undefined,
    bDayUser : null,
   };
     
// Завдання 5
let isAdult = confirm("Have you reached adulthood?");
console.log(isAdult);

// Завдання 6
let name = "Anhelina";
let surName = "Nedoshytko";
let group = "KI-502";
let birthYear = 2001; 
let married = false;
let nullVariable = null;
let  undefVariable;


console.log(typeof birthYear); // "number"
console.log(typeof married); // "boolean"   
console.log(typeof name); // "string"
console.log(typeof undefVariable); // "undefined"
console.log(typeof nullVariable); // "object"

//Завдання 7
let login = prompt("What is your name?");
let email = prompt("What is your email?");
let pass =  prompt("Enter your password");;
alert("Dear " + login +", your email is " + email + ", your password is "+ pass);

//Завдання 8
let sec = prompt("enter number of seconds");
let hours = sec/3600;
let days = hours/24; 
let months = days/30;

alert(sec + " sec. it is -  \n" + hours.toFixed(2) + " hours \n" + days.toFixed(2) + " days \n" + months.toFixed(2) + " months");
