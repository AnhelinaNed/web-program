// Завдання 1
let x = 1;
let y = 2;
let res1 = String(x) + String(y);// Допишіть код (використовувати змінні x і y)
console.log(res1); // "12"
console.log(typeof res1); // "string"

let res2 = (x < y) ? "true2" : "false2";// Допишіть код (використовувати змінні x і y)
console.log(res2); // "true2"
console.log(typeof res2); // "string"`

let res3 = x < y;// Допишіть код (використовувати змінні x і y)
console.log(res3); // true
console.log(typeof res3); // "boolean"

let res4 = parseInt('s'+ x + y);// Допишіть код (використовувати змінні x і y)
console.log(res4); // NaN
console.log(typeof res4); // "number"

// Завдання 2
let inputNum = prompt("Введіть число:");
let resOut = "";
resNum = (inputNum % 2 == 0  && inputNum > 0)? "парне додатнє" : "непарні";
if (inputNum % 2 == 0  && inputNum > 0) { resOut = "парне додатнє"}
if (inputNum % 7 == 0){ resOut = resOut + " кратне 7"}
console.log(resOut); 

//Завдання 3
let aisAdult = prompt("Введіть Ваш вік:");
if (aisAdult >=18 ){ console.log("Ви досягли повнолітнього віку"); }
else {console.log("Ви ще надто молоді"); }

//Завдання 4
let a = Number(prompt("Введіть довжину сторони а "));
let b = Number(prompt("Введіть довжину сторони b "));
let c = Number(prompt("Введіть довжину сторони c "));

//a)
let p = (a+b+c)/2;
let S = ((p * ( p - a ) * ( p - b ) * ( p - c )) ** (1/2)).toFixed(3);
//console.log("півпериметр p= "+ p);
console.log("Площа трикутника S= "+ S); 

//b)
if ((a**2 + b**2 == c**2) || (b**2 + c**2 == a**2) || (a**2 + c**2 == b**2)) console.log("трикутник прямокутний"); 

//Завдання 4
let h=(new Date()).getHours();
//let h = Number(prompt("година "));

//1
let res = (h > 23 || h <= 6) ? "Доброї ночі" : (h > 6 && h <= 11) ? "Доброго ранку": (h > 11 && h <= 18) ? "Доброго дня" : (h > 18 && h <= 23) ? "Доброго вечора" : false;
console.log(res);

//2
if (h > 23 || h <= 6) console.log("Доброї ночі") ;
else if (h > 6 && h <= 11) console.log("Доброго ранку"); 
else if (h > 11 && h <= 18) console.log("Доброго дня"); 
else if (h > 18 && h <= 23) console.log("Доброго вечора"); 

