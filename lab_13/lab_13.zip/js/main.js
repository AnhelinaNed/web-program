// Завдання 1
const arr = [];   
arr[1] = 7;             //1
arr[2] = "text";        //2
arr[3] = true;          //3
arr[4] = null;          //4
console.log(arr.length);    //5
arr[5] = prompt("Введіть число:");  //6
console.log(arr[5]);  

console.log(arr);   
arr.shift();         //7     
//arr.splice(0,1);   //7
console.log(arr);     

//Завдання 2
let cities = ["Ternopil", "Lviv", "Warsaw"];
let myString = "";
for(let count = 0; count < cities.length; count++) {
    myString += cities[count] +(count< cities.length - 1 ? '*' : "");
    }   
console.log(myString);

//Завдання 3
let mas = [2 ,3, 4, 5];
let dob = 1;
for (let i = 0; i < mas.length; i++){
dob *= mas[i]; }
console.log(dob);

let count2 = 0;
let dob2 = 1;
while(count2 < mas.length){
dob2 *= mas[count2]; 
count2 ++;
}
console.log(dob2);

//Завдання 4
for (let j = 0 ; j <=15; j++){
   console.log(j + ((j % 2 == 0) ? " is even" : " is odd"));
}

//Завдання 5
let masRandom = new Array();

function randArray(k){
for (let i = 0; i < k; i++) {
 masRandom[i] = Math.floor(Math.random()*500 + 1);  
}   
}
randArray(5);
console.log(masRandom);

//Завдання 6
function raiseToDegree(a,b){
if (Number.isInteger(a) && Number.isInteger(b)){
    return a**b;    
}
    else return "parametr is NOT Integer";
}

console.log(raiseToDegree(Number(prompt("a= ")),Number(prompt("b= "))));

//Звадання 7

function findMin(){
    let min = arguments[0];
    for(let i = 1; i < arguments.length; i++){
       if (arguments[i] < min) min = arguments[i] ;
    }
   return min;
}

console.log(findMin(12, 14, 4, -4, 0.2));

//Завдання 8

function findUnique(arr){
let ret = true;
for (let i of arr){
    let a = arr[0];
    if (arr.includes(a,1)) { ret = false; break;}
    else {arr.shift();}
}   
    return ret;
}

console.log(findUnique([1, 2, 3, 5, 3]));
console.log(findUnique([1, 2, 3, 5, 11]));

//Завдання 9

function lastElem(arr,n){
if (n === undefined) n = 1;
//n = - n;
    let ar = arr.slice(-n);
return ar;
}

console.log(lastElem([3, 4, 10, -5]));
console.log(lastElem([3, 4, 10, -5],2));
console.log(lastElem([3, 4, 10, -5],8));


//Завдання 10*s

function UpperText(str){
    return str.replace(/(^|\s)\S/g, function(a) {return a.toUpperCase()});
}
let Str = UpperText('i love java script');
console.log(Str);
