// Завдання 1
function calcRectangleArea(width, height) {
    width = parseFloat(width);
    height = parseFloat(height);
    console.log(width);
    console.log(height);
    if (isNaN(width) || isNaN(height)) {
        alert("ardguments are Not Numbers!");
        throw new Error("ardguments are Not Numbers!");
    }
    let S = width * height;
    return S;
}

try {
    let res = calcRectangleArea(prompt("Enter width:"), prompt("Enter height:"));
    console.log(res);
}
catch (exception) {
    console.log(exception.name);
    console.log(exception.message);
    console.log(exception.stack);
}

//Завдання 2

function isEmpty(str) {
    if (str.trim() == '')
        return true;

    return false;
}

function checkAge() {
    let Mess1 = "The field is empty! Please enter your age";
    let Mess2 = "Your age is Not number!";
    let Mess3 = "Your age is less than 14 years";

    let age = prompt("Enter  Your age:");
    if (isEmpty(age)) throw new Error(Mess1);
    age = parseFloat(age);
    if (isNaN(age)) throw new Error(Mess2);
    if (age < 14) throw new Error(Mess3);
}

try {
    checkAge();
    alert("You have access to watch the movie");
}
catch (exception) {
    alert(exception.message);
    console.log(exception.name);
    console.log(exception.message);
}



//Завдання 3
function showUser(id) {
    let er = false;
    if (id < 0) er = true;
    let user = {
        id: id,
        err: er
    }
    return user
}
let arr = [];
function showUsers(ids) {
    
    for (let i = 0; i < ids.length; i++) {
        if (showUser(ids[i]).err)
            console.log("Error: ID must not be negative:" + showUser(ids[i]).id);
        else arr.push(showUser(ids[i]));
    }
    return arr;
}

console.log(showUsers([7, -12, 44, 22]));

//Завдання 4
function MonthException(message) {
    this.name = 'MonthException';
    this.message = message;
}

let errMes = new MonthException('Incorrect month number');

function showMonthName(month) {
    const monthArr = ["", "January", "February", "March", "April", "May", "June", "July",
        "August", "September", "October", "November", "December"];
            
        if (monthArr[month] === undefined) throw new Error(errMes.name + '  ' + errMes.message);       
    try {
        
        return monthArr[month];
    }
    catch (exception) {
        console.log(exception.message);
    }
}

console.log(showMonthName(prompt("Enter num Month:")));

